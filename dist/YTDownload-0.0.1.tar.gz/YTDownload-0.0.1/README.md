# What is YTDownload
YTDownload is a Free & Open-Source Downloader for YouTube Videos
To use it use this Command :
```bash
$ python -m YTDownload
```

And Download by :
```bash
$ pip install YTDownload
```